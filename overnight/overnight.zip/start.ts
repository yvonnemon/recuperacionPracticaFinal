import {SampleServer} from "./SampleServer";

const server = new SampleServer();
server.start(8080);