"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SampleServer_1 = require("./SampleServer");
var server = new SampleServer_1.SampleServer();
server.start(8080);
